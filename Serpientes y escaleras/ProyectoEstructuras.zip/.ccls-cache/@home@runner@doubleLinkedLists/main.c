#include "listD.h"

int main(void) {
  List l;
  createList(&l);
  puts("Insert at first\n");
  insertAtfirst(&l, 'A');
  insertAtfirst(&l, ' ');
  insertAtfirst(&l, ' ');
  insertAtfirst(&l, ' ');
  printList(&l);
  puts("\n Insert at first\n");
  changeNodeValue(&l, 1, 'A');
  changeNodeValue(&l, 4, ' ');
  printList(&l);
}