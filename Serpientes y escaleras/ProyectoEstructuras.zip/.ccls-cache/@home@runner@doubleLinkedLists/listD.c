#include "listD.h"


Node* createNode(element e){
  Node *t;
  t = (Node*)malloc(sizeof(Node));
  t -> e = e;
  //t -> next = NULL;
  return t;
}

void createList(List *l){
  l -> head = l -> tail = NULL;
}

void insertAtfirst(List *l, element e){
  Node *n;
  n = createNode(e);
  if (l -> head == NULL){
    n -> prev = NULL;
    n -> next = NULL;
    l -> head = n;
    l -> tail = n;
  }else {
    l ->head ->prev = n;
    n -> next = l -> head;
    n -> prev = NULL;
    l -> head = n;
  }
}

void insertBeforeNode(List *l, int n,  element e){
  Node *new;
  new = createNode(e);
  if (n != 1 && l -> head != NULL){
    Node *aux = l -> head;
    int counter = 1;
    while(counter != n && aux != NULL){
      aux = aux -> next;
      counter++;
    }
    Node *aux2 = aux -> prev;
    aux -> prev = new;
    new -> next = aux;
    aux2 -> next = new;
    new -> prev =  aux2;
  }
  else{
     insertAtfirst(l, e);
  }
}

void changeNodeValue(List *l, int n, element e) {
  if (n > 0 && l->head != NULL) {
    Node *aux = l->head;
    int counter = 1;
    while (counter != n && aux != NULL) {
      aux = aux->next;
      counter++;
    }
    if (aux != NULL) {
      aux->e = e;
    }
  }
}


void printNode(Node *node) {
    printf("┌───┐\n");
    printf("│ %c │\n", node->e);
    printf("└───┘\n");
}

void printList(List *list) {
    Node *current = list->head;
    while (current != NULL) {
        printNode(current);
        current = current->next;
    }
}


