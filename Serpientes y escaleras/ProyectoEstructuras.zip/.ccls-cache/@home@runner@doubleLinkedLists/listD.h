#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef char element; 

typedef struct node {
  element e;
  struct node *prev;
  struct node *next;
}Node;

typedef struct list{
  Node *head;
  Node *tail;
}List;

//Prototypes
Node* createNode(element e);
void createList(List *l);
void insertAtfirst(List *l, element e);
void insertBeforeNode(List *l, int n, element e);
void deleteNode(List *l, int n);
void printNode(Node *node);
void printList(List *list);
void changeNodeValue(List *l, int n, element e);

