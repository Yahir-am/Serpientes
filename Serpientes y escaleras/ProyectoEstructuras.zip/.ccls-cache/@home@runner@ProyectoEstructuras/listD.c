#include "listD.h"

/*funcion para crear el nodo
toma el elemento a insertar que es es jugador o un espacio vacio
y el id que identificara la celda*/
Node* createNode(element e, int u){
  Node *t;
  t = (Node*)malloc(sizeof(Node));
  t -> e = e;
  t -> u = u;
  return t;
}

void createList(List *l){
  l -> head = l -> tail = NULL;
}

void insertAtfirst(List *l, element e, int u){
  Node *n;
  n = createNode(e, u);
  if (l -> head == NULL){
    n -> prev = NULL;
    n -> next = NULL;
    l -> head = n;
    l -> tail = n;
  }else {
    l ->head ->prev = n;
    n -> next = l -> head;
    n -> prev = NULL;
    l -> head = n;
  }
}

/*Con esta funcion creamos la lista  insertando el elemento y el id*/
void llenarLista(List *l, int tamano, int *arr){
  for(int i = 0; i < tamano*tamano; i++){
    insertAtfirst(l, ' ', arr[i]);
  }
}

/*Con esta funcion cambiamos el valor del elemento de la celda
(de espacio vacio a jugador o  viceversa)*/

void changeNodeValue(List *l, int n, element e) {
  if (n > 0 && l->head != NULL) {
    Node *aux = l->head;
    int counter = 1;
    while (counter != n && aux != NULL) {
      aux = aux->next;
      counter++;
    }
    if (aux != NULL) {
      aux->e = e;
    }
  }
}

element getIdByPosition(List *l, int position) {
   Node *current = l->head;
   int counter = 1;

   while (current != NULL) {
      if (counter == position) {
         return current->u;
      }
      current = current->next;
      counter++;
   }

   return 0;  // Si no se encuentra un nodo en la posición dada, se devuelve 0
}

int findIdenticalIdByPosition(List *l, int id, int position) {
   Node *current = l->head;
   int counter = 1;

   while (current != NULL) {
      if (current->u == id && current->u != -1 && counter != position) {
         return counter;
      }
      current = current->next;
      counter++;
   }

   return 0;  // No se encontró otro nodo con el identificador dado que no sea 0, excluyendo la posición actual
}





int getNewPositionByOldPosition(List *l, int position) {
    int p = getIdByPosition(l, position);
  
    if (p != -1) {
        char letra = (p % 2 == 0) ? 'S' : 'E';
        
        if (letra == 'S') {
            int s1 = findIdenticalIdByPosition(l, p, position);
            return s1;
        } else if (letra == 'E') {
            int e1 = findIdenticalIdByPosition(l, p, position);
            return e1;
        }
    
    }else{
      return 0;
    }
    
    // Agrega un valor de retorno por defecto o realiza alguna otra acción aquí si es necesario
    
    return 0;
}



void movePlayer(List *l, int oldPosition, int newPosition, element e) {
      changeNodeValue(l, oldPosition, ' ');
      changeNodeValue(l, newPosition, e);
}

/**Esta funcion imprimer la lista en forma de tablero  de n x n, 
verifica el ID asociado a cada celda y lo imprime***/
void printGrid(List *list) {
  int position = 0;
  Node *current = list->head; // para dar seguimiento al ID

  for (int i = 0; i < tamTablero; i++) { // por cada renglón
    Node *aux = current; // para dar seguimiento al elemento

    for (int j = 0; j < tamTablero; j++) {
      int numero = current->u;
      char letra = (numero % 2 == 0) ? 'S' : 'E'; /* operador ternario para 
 asignar 'S'erpiente o 'E'scalera de acuerdo al módulo (si es par o no) */

      if (numero != -1) { 
        printf("┌%c%d─────┐  ", letra, numero);
      } else {
        printf("┌───────┐  ");
      }

      current = current->next;
    }

    printf("\n");

    for (int j = 0; j < tamTablero; j++) {
      printf("│   %c   │  ", aux->e);
      aux = aux->next;
    }

    printf("\n");

    for (int j = 0; j < tamTablero; j++) {
      position++;
      if (position >= 10 ) {
        printf("└─────%d┘  ", position);
      } else {
        printf("└──────%d┘  ", position);
      }
    }

    printf("\n");
    position++;
  }
}


//*Con esta funcion puedes tirar mas de un dado*/
int tirarDados(int numDados){
    int suma = 0;
    for(int i = 0; i < numDados; i++){
      int aleatorio =  (rand() % 6) + 1;
     suma = suma + aleatorio;
    }
    printf("\nAl tirar los dados salió: %d \n", suma);

    return suma;
}

//Esta funcion es para crear un arreglo de ID's del mismo tamano que la lista-tablero */
int* id(int cantidadNumeros) {
    int size = cantidadNumeros * cantidadNumeros;
    int* numeros = (int*)malloc(size * sizeof(int));

    // Llena el arreglo con los números en orden ascendente
    for (int i = 1; i <= cantidadNumeros; i++) {
        numeros[i - 1] = numeros[i + cantidadNumeros - 1] = i; // i + cantidadNumeros para llenar la otra mitad
    }

    // Rellena el resto con ceros
    for (int i = cantidadNumeros * 2; i < size; i++) {
        numeros[i] = -1;
    }

    // Revuelve aleatoriamente
    srand(time(NULL));
    for (int i = size - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = numeros[i];
        numeros[i] = numeros[j];
        numeros[j] = temp;
    }
    return numeros;
}

bool isLastNodeEven(List *l) {
  if (l->tail != NULL) {
    return (l->tail->u % 2 == 0);
  }
  return false;
}




int  conditions2move( List *l, int position, int id) {
  
  if (id != -1) {
    int newPosition = getNewPositionByOldPosition(l, position);
    printf("\nPosición del nodo par: %d \n", newPosition);
    char letra2;
    letra2 = (id % 2 == 0) ? 'S' : 'E';
    if (letra2 == 'S' && position > newPosition) {
      puts("\nEntró en Serpiente\n");
      movePlayer(l, position, newPosition, 'A');
      position = newPosition; // Actualizamos la posición
    } else if (letra2 == 'E' && position < newPosition) {
      puts("\nEntró en Escalera\n");
      movePlayer(l, position, newPosition, 'A');
      position = newPosition; // Actualizamos la posición
    }
  }
  return position;
}

void initializeList(List* lista) {
  createList(lista);
  int* arreglo = id(tamTablero);
  llenarLista(lista, tamTablero, arreglo);
}

void printAndCheckPosition(List* lista, int posicion) {
  printGrid(lista);
  printf("La posición en la que se quedó fue %d\n", posicion);
  puts("\n------------------\n");
}



int getNextPosition(List* lista, int posicion, int jugada) {
  int nuevaPosicion = posicion + jugada;
  printf("%d +  %d =  %d \n", posicion, jugada, nuevaPosicion);
  int identificador = getIdByPosition(lista, nuevaPosicion);
  printf("\nPosición a la que esperas moverte: %d\n", nuevaPosicion);
  nuevaPosicion = conditions2move(lista, nuevaPosicion, identificador);
  movePlayer(lista, posicion, nuevaPosicion, 'A');
  return nuevaPosicion;
}


int casoEspecial(List* lista, int posicion) {
  if (getIdByPosition(lista, posicion) != -1) {
    if (getIdByPosition(lista, posicion) % 2 != 0) {
      int nuevaPosicion = getNewPositionByOldPosition(lista, 1);
      posicion = nuevaPosicion; // Actualizamos la posición
      movePlayer(lista, 1, posicion, 'A');
      puts("¡Que suerte! Empezaste con una escalera !");
      printAndCheckPosition(lista, posicion);
    } else {
      printGrid(lista);
      printf("La posición en la que se quedó fue %d\n", posicion);
      puts("\n------------------\n");
    }
  } else {
    printGrid(lista);
    puts("\n");
  }
  return posicion;
}
