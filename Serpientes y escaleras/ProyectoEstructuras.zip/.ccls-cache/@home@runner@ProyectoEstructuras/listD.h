#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include<unistd.h>

#define tamTablero 9


typedef char element; 

typedef struct node {
  element e;
  element u;
  struct node *prev;
  struct node *next;
}Node;


typedef struct list{
  Node *head;
  Node *tail;
}List;

//Prototypes
Node* createNode(element e, int u );
void createList(List *l);
void insertAtfirst(List *l, element e, int u);
void llenarLista(List *l,int tamano, int *arr);
void changeNodeValue(List *l, int n, element e);
void movePlayer(List *l,  int oldPosition, int newPosition, element e);
void printGrid(List *l);
int tirarDados(int numDados);
int* id(int cantidadNumeros);
element getIdByPosition(List *l, int position) ;
int findIdenticalIdByPosition(List *l, int id, int position);
int getNewPositionByOldPosition(List *l, int position);
bool isLastNodeEven(List *l);
int  conditions2move( List *l, int position, int id);
void initializeList(List* lista);
void printAndCheckPosition(List* lista, int posicion);
int getNextPosition(List* lista, int posicion, int jugada);
int casoEspecial(List* lista, int posicion);