#include "listD.h"

int main(void) {
  srand(time(NULL));
  List lista;
  initializeList(&lista); // Inicializar el tablero

  // Este loop evita que la meta sea una serpiente y se cicle
  while (isLastNodeEven(&lista)) {
    initializeList(&lista);
  }

  // Notas
  puts("\nE representa escalera y\nS representa serpiente\n");
  puts("***** INICIO ******\n\n");

  int posicion = 1; // Posición inicial
  int numeroJugada = 1;

  // Primera posición
  changeNodeValue(&lista, posicion, 'A');
  posicion = casoEspecial(&lista, posicion);
  // sleep(1);   // Espera 1 segundo
 /* printf("\nPresiona una tecla...\n");
  getchar();       // Lee un carácter del teclado
  system("clear"); // Limpia pantalla en Linux o macOS
*/
  while (posicion < tamTablero * tamTablero) {
    printf("Jugada número %d\n", numeroJugada); // Título

    int jugada = tirarDados(2);

    // Condiciones de tiro
    if (jugada > tamTablero * tamTablero - posicion) {
      puts("\nLo siento, el número excede las casillas disponibles, por favor "
           "tira otra vez\n");
      // sleep(1);   // Espera 1 segundo
    /*  printf("\nPresiona una tecla...\n");
      getchar();       // Lee un carácter del teclado
      system("clear"); // Limpia pantalla en Linux o macOS
      */numeroJugada++;
      continue; // Volver a empezar el bucle sin actualizar la posición
    }
    printf("posicion anterior %d\n",posicion);
    int nuevaJugada = getNextPosition(&lista, posicion, jugada);
    printAndCheckPosition(&lista, nuevaJugada);

    posicion = nuevaJugada; // Actualizamos la posición actual del jugador
    numeroJugada++;

    // sleep(1);   // Espera 1 segundo
   /* printf("\nPresiona una tecla...\n");
    getchar();       // Lee un carácter del teclado
    system("clear"); // Limpia pantalla en Linux o macOS*/
  }

  puts("¡Felicidades, has llegado a la posición final del tablero!");

  return 0;
}
